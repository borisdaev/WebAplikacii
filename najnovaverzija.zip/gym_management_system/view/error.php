<!DOCTYPE html>
<html>
    <head>
        <title>Collective</title>
        <link rel="stylesheet" type="text/css" href="main.css"/>
    </head>
    <body>
        <header>
            <h1>Collective</h1>
        </header>
        <main>
            <h1 class="top">Error</h1>
            <p><?php echo $error; ?></p>
        </main>
    </body>
</html>
