<?php
require('../../model/database.php');
require('../../model/kosnicka_db.php');
require('../../model/kosnicka.php');
require('../../model/product_db.php');
require('../../model/product.php');
require('../../model/korisnik.php');
require('../../model/korisnik_db.php');

$kosnicki = kosnicka_db::getKoshnichki();
    $proizvodi = product_db::getProducts();
    
    if(isset($_SESSION['korisnik']))
    {
        $ime=$_SESSION['korisnik'];
        $korisnik=korisnik_db::getKorisnik($ime,'');
    }
include('view/OrderedArticles.php');

?>