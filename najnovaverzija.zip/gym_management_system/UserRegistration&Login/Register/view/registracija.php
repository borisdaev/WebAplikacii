<?php include('../../view/header.php'); ?>

            <br>
            <br>
            <br>

            <div class="wrapper">

            <?php 
                    if(isset($_SESSION['mailIspraten'])) {
                        echo $_SESSION['mailIspraten'];
                        unset($_SESSION['mailIspraten']);
                    }
                ?>
                <h1>Registration</h1>
                <form action="" method="POST">
                    <div class="txt_field">
                        <input type="text" name="name" required>
                        <span></span>
                        <label>Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="surname" required>
                        <span></span>
                        <label>Surname</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="city" required>
                        <span></span>
                        <label>City</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="phoneNumber" required>
                        <span></span>
                        <label>PhoneNumber</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="email"  required>
                        <span></span>
                        <label>Email</label>
                    </div>
                    <div class="txt_field">
                        <input type="password" name="password" required>
                        <span></span>
                        <label>Password</label>
                    </div>
                    <input type="submit" name="submit" value="Register">
                </form>
            </div>

<?php include('../../view/footer.php'); ?>