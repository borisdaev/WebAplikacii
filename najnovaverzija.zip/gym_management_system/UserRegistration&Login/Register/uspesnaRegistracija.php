<?php
    require('../../model/database.php');
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require '../../vendor/autoload.php';
    require '../../vendor/phpmailer/phpmailer/src/Exception.php';
    require '../../vendor/phpmailer/phpmailer/src/PHPMailer.php'; 
    require '../../vendor/phpmailer/phpmailer/src/SMTP.php'; 



    $mail = new PHPMailer;

    global $mail;
    
    try {
        $mail->SMTPDebug = 1;
        $mail->isSMTP();
        $mail->Host = 'smtp-mail.outlook.com';
        $mail->SMTPAuth = true;
        $mail->Username   = 'collectivemkweb@outlook.com'; 
        $mail->Password   = 'TestTest123';
        $mail->SMTPSecure = 'STARTTLS';
        $mail->Port = 587;

        $email = $_GET['email'];

        $mail->setFrom('collectivemkweb@outlook.com', 'CollectiveMK');
        $mail->addAddress($email);

        $ime = $_GET['name'];
        $prezime = $_GET['surname'];

        $body = '<p>Почитуван/а '. $ime . ' ' . $prezime . ',<br><br> Успешно се регистриравте на нашата платформа.</p>';

        $mail->isHTML(true);
        $mail->Subject = 'Registration successfull.';

        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        $mail->send();
        $_SESSION['mailIspraten'] = "<div style='color:blueviolet;font-size:15px;'>Проверете го Вашиот mail за потврда за успешна регистрација.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Register?result=reload');
    }catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
?>