<?php if(!isset($_SESSION['korisnik'])) {include('../view/header.php'); } else {include('../UserRegistration&Login/view/header.php'); }?>

<br<br<br><br><br><br>

<section class="food-search text-center" style="background-color:rgb(105, 136, 126);background-size: cover;background-repeat: no-repeat;
  background-position: center;padding: 7% 0;text-align:center;">
        <div class="container" style="width: 80%;margin: 0 auto;padding: 1%;">
            <h2>Category<a href="#">"<?php echo $kategorija->getIme(); ?>"</a></h2>
        </div>
</section>

<section style="background-color: blueviolet;padding: 4% 0;">
    <div class="container" style="width: 80%;margin: 0 auto;padding: 1%;">
    <?php 
                if(isset($_SESSION['added-to-cart'])) 
                {
                    echo $_SESSION['added-to-cart'];
                    unset($_SESSION['added-to-cart']);
                }
            ?>
        <h2 class="text-center" style="text-align:center;">Достапни производи</h2>
        <?php
        $categoryName=$kategorija->getIme(); 
        if($proizvodi!="")
        { foreach($proizvodi as $proizvod) :   ?>
                    
        <div class="food-menu-box" style="width: 43%;margin: 1%;padding: 2%;float: left;background-color: white;border-radius: 15px;">
                        <div class="food-menu-img" style="width: 20%;float: left;">
                            <?php 
                                
                                 $slika=$proizvod->getSlika();
                                if($slika=="") {
                                    echo "<div class='error'>Нема достапна слика за овој производ.</div>";
                                } else {
                                    ?>
                                        <img src="<?php echo 'http://localhost/gym_management_system/';?>images/product/<?php echo $slika;?>" class="img-responsive img-curve" style="width: 100%;border-radius: 15px;">
                                    <?php
                                }
                            ?>
                        </div>
                        <div class="food-menu-desc" style="width: 70%;float: left;margin-left: 8%;">
                            <h4 style="color:black;"><?php echo $proizvod->getIme(); ?></h4>
                            <p class="food-price" style="font-size: 1.2rem;margin: 2% 0;color:black;"><?php echo $proizvod->getCena(); ?> денари</p>
                            <br>
                            <?php if(!isset($_SESSION['korisnik'])) { ?>
                            <a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login" class="btn btn-primary" style="background-color: blueviolet;padding: 1%;color: black;
                                            text-decoration: none;font-weight: bold;">Додади во Кошничка</a>
                            <?php } else { ?>
                             <a href="<?php echo 'http://localhost/gym_management_system/'; ?>OurPlans?id=<?php echo $korisnik->getuserID(); ?>&action=add&pid=<?php echo $proizvod->getID(); ?>&action=add&cid=<?php echo $kategorija->getID(); ?>" class="btn btn-primary" style="background-color: blueviolet;padding: 1%;
                                                color: black;text-decoration: none;font-weight: bold;">Додади во Кошничка</a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php endforeach; ?> 
                    <?php
                }
             else {
                echo "<div class='error'>Нема достапни производи од $categoryName kategorijata.</div>";
            }
        ?>
        <div class="clearfix"></div>
    </div>
</section>


<br><br><br><br><br><br><br><br><br>


<?php include('../view/footer.php') ?>