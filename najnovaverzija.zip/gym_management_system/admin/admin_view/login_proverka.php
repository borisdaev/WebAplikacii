<?php
    
    if(!isset($_SESSION['user'])) { 
        $_SESSION['no-login-message'] = "<div class='error text-center'>You are not logged in .</div>";
        header('location:'.'http://localhost/gym_management_system/'.'admin/Login');
    }
?>