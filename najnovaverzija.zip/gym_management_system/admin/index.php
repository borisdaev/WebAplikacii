<?php
require('../model/database.php');
require('../model/category_db.php');
require('../model/category.php');
require('../model/product.php');
require('../model/product_db.php');



include('admin_view/login_proverka.php');



$kategorii=category_db::getCategories();
$products=product_db::getProducts();


include('admin_home.php');
 
    
 
?>