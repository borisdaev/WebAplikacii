<?php
class kosnicka_db{
    public static function getKoshnichki()
    {
        global $db;
        
        $query="SELECT * FROM kosnicka
                ORDER BY id";
       
        $result=mysqli_query($db,$query);

        $carts = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $cart = new kosnicka($row['id'],
                                 $row['userID'],
                                 $row['productID'],
                                $row['isporacano']);
        $carts[]=$cart;
       }
       return $carts;

        }
        else
        {
            $carts="";
            return $carts;
        }
       
        
    }

    public static function getKoshnichkiByKorisnik($korisnik_id)
    {
        global $db;
        
        $query="SELECT * FROM kosnicka
                WHERE userID='$korisnik_id'";
       
        $result=mysqli_query($db,$query);

        $carts = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $cart = new kosnicka($row['id'],
                                 $row['userID'],
                                 $row['prodcutID'],
                                 $row['isporacano']);
        $carts[]=$cart;
       }
       return $carts;

        }
        else
        {
            $carts="";
            return $carts;
        }
       
        
    }

    
    public static function getKoshnichkaByID($cart_id)
    {
      global $db;
    
    $query = "SELECT * FROM kosnicka
              WHERE id = $cart_id";    

    $result=mysqli_query($db,$query);
    $row = $result->fetch_assoc();
    $cart = new kosnicka($row['id'],
                           $row['userID'],
                           $row['productID'],
                           $row['isporacano']);
    return $cart;

    }


    public static function addKoshnichka($cart) {
        global $db;
    
        $cart_id = $cart->getID();
        $kid = $cart->getKorisnikID();
        $pid = $cart->getProizvodID();
        $isp = $cart->getIsporacano();

        

        $query = "INSERT INTO kosnicka
                  SET id = '$cart_id', userID =  '$kid',productID = '$pid', isporacano = '$isp'";
       $result=mysqli_query($db, $query);
       if($result==true){
        return true;
       }
       else{
        return false;
       }
    }

    public static function deleteKoshnichka($cart_id) {
       global $db;
   
        $query = "DELETE FROM kosnicka
                  WHERE id = '$cart_id'";
        $result=mysqli_query($db, $query);
        if($result==true){
            return true;
        }
        else {
            return false;
        }
    }
    
    public static function deleteKoshnichki($korisnik_id){
        global $db;

        $query = "DELETE FROM kosnicka
                  WHERE isporacano = 'no' AND userID = '$korisnik_id'";
        $result=mysqli_query($db, $query);

        if($result==true){
            return true;
        }
        else {
            return false;
        }
    }

    public static function naracaj($korisnik_id){
        global $db;

        $query = "UPDATE kosnicka
                  SET isporacano = 'yes'
                  WHERE isporacano = 'no' AND userID = '$korisnik_id' ";
        $result=mysqli_query($db, $query);

        if($result==true){
            return true;
        }
        else {
            return false;
        }
    }



}