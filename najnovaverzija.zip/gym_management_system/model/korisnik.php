<?php
class korisnik{
    private $userID;
    private $city;
    private $name;
    private $surname;
    private $email;
    private $password;
    private $phoneNumber;
    private $kosnickaID;

    public function __construct($korID , $grad , $ime , $prezime , $em, $pass , $tel, $kosID) {
        $this->userID = $korID;
        $this->city = $grad;
        $this->name = $ime;
        $this->surname = $prezime;
        $this->email = $em;
        $this->password = $pass;
        $this->phoneNumber = $tel;
        $this->kosnickaID = $kosID;
    }
    public function getuserID() {
        return $this->userID;
    }
    public function getCity() {
        return $this->city;
    }
    public function getName() {
        return $this->name;
    }
    public function getSurname() {
        return $this->surname;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getPassword() {
        return $this->password;
    }
    public function getphoneNumber() {
        return $this->phoneNumber;
    }
    public function getkosnickaID() {
        return $this->kosnickaID;
    }
    


}
?>