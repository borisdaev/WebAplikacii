<?php
class korisnik_db{
    
    public static function getKorisnik($em, $pw){
       global $db;
       
       if($pw!='')
       {
       $query = "SELECT * FROM `user`
              WHERE email='$em' AND `password`='$pw'";  
       }
       else
       { 
        $query = "SELECT * FROM `user`
        WHERE email='$em'";

       }  

    $result=mysqli_query($db,$query);
    $count = mysqli_num_rows($result);
    if($count > 0)
    {
    $row = $result->fetch_assoc();
    $korisnik = new korisnik($row['userID'],
                            $row['city'],
                            $row['name'],
                            $row['surname'],
                            $row['email'],
                            $row['password'],
                            $row['phoneNumber'],
                            $row['kosnickaID']);
    return $korisnik;
    }else
    {
        $korisnik="";
        return $korisnik;
    }
    }

    public static function addKorisnik($korisnik) {
        global $db;
    
        $korisnik_id = $korisnik->getuserID();
        $city=$korisnik->getCity();
        $ime = $korisnik->getName();
        $prezime = $korisnik->getSurname();
        $em = $korisnik->getEmail();
        $pw = $korisnik->getPassword();
        $telefon=$korisnik->getphoneNumber();
        $kosnickaID=$korisnik->getkosnickaID();        

        $query = "INSERT INTO `user` SET
            userID = '$korisnik_id', city='$city', name='$ime', surname='$prezime', email='$em', `password`='$pw', phoneNumber='$telefon',kosnickaID='$kosnickaID'"; 

        $result = mysqli_query($db, $query);

        if($result==true)
        {
            return true;

        }
        else
        {
           return false;
        }
       
    }


}