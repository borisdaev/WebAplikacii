<?php
    class Admin{
        private $id;
        private $name;
        private $surname;
        private $username;
        private $password;

        public function __construct($id , $name , $surname , $username , $password){
            $this->id=$id;
            $this->name=$name;
            $this->surname=$surname;
            $this->username=$username;
            $this->password=$password;
        }

        public function get_id(){
            return $this->id;
        }

        public function set_id($value){
            $this->id=$value;
        }

        public function get_name(){
            return $this->name;
        }

        public function set_name($value){
            $this->name=$value;
        }

        public function get_surname(){
            return $this->surname;
        }

        public function set_surname($value){
            $this->surname=$value;
        }

        public function get_username(){
            return $this->username;
        }

        public function set_username($value){
            $this->username=$value;
        }

        public function get_password(){
            return $this->password;
        }

        public function set_password($value){
            $this->password=$value;
        }



    }


?>