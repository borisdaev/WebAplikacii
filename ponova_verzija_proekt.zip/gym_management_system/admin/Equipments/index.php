<?php
require('../../model/database.php');
require('../../model/category.php');
require('../../model/category_db.php');


include('../admin_view/login_proverka.php');

$category_id = filter_input(INPUT_GET, 'id', 
FILTER_VALIDATE_INT);
$action = filter_input(INPUT_GET, 'action');
$slika = filter_input(INPUT_GET, 'slika');

if($category_id != NULL && $action == 'delete')
{
    if($slika != "") {
        $path = "../../images/category/".$slika;
        $remove = unlink($path);
        if($remove == false) {
            $_SESSION['remove'] = "<div class='error'>Picture isn't deleted successfully..</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments');
            die();
        }
    }
   $check=category_db::deleteCategory($category_id);

   if($check == true) {
       //Category Deleted
       //Create Session Variable to Display Message 
       $categories=category_db::getCategories();
       $_SESSION['delete'] = "<div class='success'>Category deleted successfully.</div>";
       //Redirect to Manage Category
       header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments');
   } else {
       //Failed to Delete Category
       $_SESSION['delete'] = "<div success='error'>Category is not deleted successfully.</div>";
       header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments');
   }
        
}

else if( $action == 'add')
{
    include('add_category.php');

    if(isset($_POST['submit'])) {
        $ime = $_POST['name'];
        if(isset($_POST['active'])) {
            $active = $_POST['active'];
        } else {
            $active = "no";
        }

        if(isset($_FILES['slika']['name'])) {
            $slika = $_FILES['slika']['name'];
            $pom = explode('.', $slika);
            $ext = end($pom);
            $slika = "category_100".'.'.$ext;
            $source_path = $_FILES['slika']['tmp_name'];
            $destination_path = "../../images/category/".$slika;
            $upload = move_uploaded_file($source_path, $destination_path);
            if($upload==false) {
                $_SESSION['upload'] = "<div class='error'>Picture isn't attached successfully.</div>";
                header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments?action=add');
                die();
            }
        } else {
            $slika = "";
        }

        $category=New category ('',$ime,$slika,$active);
        $res=category_db::addCategory($category);

        if ($res == true) {
            $_SESSION['add'] = "<div class='success'>Category added successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments');
        } else {
            $_SESSION['add'] = "<div class='error'>Category is not added successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/Equipments');
        }
    }
}
else
{
    $categories=category_db::getCategories();
    include('manage_category.php');
}

?>