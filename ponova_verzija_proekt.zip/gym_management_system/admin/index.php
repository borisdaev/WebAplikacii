<?php
require('../model/database.php');
require('../model/admin_db.php');
require('../model/admin.php');

include('admin_view/login_proverka');

include('view_home_admin.php');

?>