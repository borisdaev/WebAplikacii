<?php 
    include('../../model/database.php');
    
    session_destroy(); 
    
    header('location:'.'http://localhost/gym_management_system/');
?>