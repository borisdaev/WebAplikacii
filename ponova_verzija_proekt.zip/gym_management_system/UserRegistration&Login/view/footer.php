<footer style="background-color: #8a2be2">
        <p class="center">&copy CollectiveMK, 2023</p>
        <img src="<?php echo 'http://localhost/gym_management_system/'?>images/logo.jpg" width="100" height="100" alt="collective" class="centerPic">
        </footer>
</body>
</html>