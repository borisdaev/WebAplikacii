<?php
class category_db{
    public static function getCategories()
    {
        global $db;
        
        $query="SELECT * FROM category
                ORDER BY id";
       
        $result=mysqli_query($db,$query);

        $kategorii = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $kategorija = new category($row['id'],
                                 $row['name'],
                                 $row['picture'],
                                 $row['active']);
        $kategorii[]=$kategorija;
       }
       return $kategorii;

        }
        else
        {
            $kategorii="";
            return $kategorii;
        }
       
        
    }
    
    public static function getCategory($category_id)
    {
      global $db;
    
    $query = "SELECT * FROM category
              WHERE id = $category_id";    

    $result=mysqli_query($db,$query);
    $row = $result->fetch_assoc();
    $kategorija = new category($row['id'],
                              $row['name'],
                              $row['picture'],
                              $row['active']);
    return $kategorija;

    }


    public static function addCategory($kategorija) {
        global $db;
    
        $category_id = $kategorija->getID();
        $ime = $kategorija->getIme();
        $Slika = $kategorija->getSlika();
        $Active = $kategorija->getActive();
        

        $query = "INSERT INTO category
                SET       
                id = '$category_id',
                name =  '$ime',
                picture = '$Slika',
                active = '$Active'
                ";
       $result=mysqli_query($db, $query);
       if($result==true){
        return true;
       }
       else{
        return false;
       }
    }

    public static function deleteCategory($category_id) {
       global $db;
   
        $query = "DELETE FROM category
                  WHERE id = '$category_id'";
        $result=mysqli_query($db, $query);
        if($result==true){
            return true;
        }
        else {
            return false;
        }
    }
}
?>