<?php
class equipments{
    private $id;
    private $ime;
    private $slika;
    private $description;

    public function __construct($id , $name , $picture , $desc){
        $this->id=$id;
        $this->ime=$name;
        $this->slika=$picture;
        $this->description=$desc;
    }

    public function getID(){
        return $this->id;
    }

    public function setID($value){
        $this->id=$value;
    }

    public function getIme(){
        return $this->ime;
    }

    public function setIme($value){
        $this->ime=$value;
    }

    public function getSlika(){
        return $this->slika;
    }

    public function setSlika($value){
        $this->slika=$value;
    }

    public function getDescription(){
        return $this->description;
    }

    public function setDescription($value){
        $this->description=$value;
    }
}

?>