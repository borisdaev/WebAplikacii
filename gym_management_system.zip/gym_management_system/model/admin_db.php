<?php
class AdminDB{
    
    public static function getAdmin($username , $password){
    
    global $db;

    $query = "SELECT * FROM `admin`
              WHERE username='$username' AND `password`='$password'";    

    $result=mysqli_query($db,$query);
    $count = mysqli_num_rows($result);
    if($count > 0)
    {
    $row = $result->fetch_assoc();
    $admin = new Admin($row['id'],
                           $row['name'],
                           $row['surname'],
                           $row['username'],
                           $row['password']);
    return $admin;
    }else
    {
        $admin="";
        return $admin;
    }

    }
}


