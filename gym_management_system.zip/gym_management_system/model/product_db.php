<?php
class product_db {
    public static function getProducts()
    {
        global $db;
        
        $query="SELECT * FROM product
                ORDER BY productID";
       
        $result=mysqli_query($db,$query);

        $proizvodi = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $proizvod = new product($row['productID'],
                                 $row['name'],
                                 $row['price'],
                                 $row['picture'],
                                 $row['active'],
                                 $row['featured'],
                                 $row['categoryID']);
        $proizvodi[]=$proizvod;
       }
       return $proizvodi;

        }
        else
        {
            $proizvodi="";
            return $proizvodi;
        }
       
        
    }
    
    
    public static function getProductsbyCategory($category_id)
    {
        global $db;
        
        $query="SELECT * FROM product
                WHERE categoryID=$category_id
                ORDER BY productID";
       
        $result=mysqli_query($db,$query);

        $proizvodi = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $proizvod = new product($row['productID'],
                                 $row['name'],
                                 $row['price'],
                                 $row['picture'],
                                 $row['active'],
                                 $row['featured'],
                                 $row['categoryID']);
        $proizvodi[]=$proizvod;
       }
       return $proizvodi;

        }
        else
        {
            $proizvodi="";
            return $proizvodi;
        }
       
        
    }
    

    public static function getProduct($product_id)
    {
      global $db;
    
    $query = "SELECT * FROM product
              WHERE productID = $product_id";    

    $result=mysqli_query($db,$query);
    $row = $result->fetch_assoc();
    $proizvod = new product($row['productID'],
                            $row['name'],
                            $row['price'],
                            $row['picture'],
                            $row['active'],
                            $row['featured'],
                            $row['categoryID']);
    return $proizvod;

    }

 
    public static function addProduct($proizvod) {
        global $db;
    
        $product_id = $proizvod->getID();
        $ime = $proizvod->getIme();
        $cena = $proizvod->getCena();
        $Slika = $proizvod->getSlika();
        $Active = $proizvod->getActive();
        $feat = $proizvod->getFeatured();
        $kID= $proizvod->getKategorijaID();
        

        $query = "INSERT INTO product SET
        productID = '$product_id',
        name = '$ime',
        price = $cena,
        picture = '$Slika',
        active = '$Active',
        featured = '$feat',
        categoryID = $kID
        ";

        $result=mysqli_query($db, $query);
        if($result==true){
        return true;
        }
        else {
            return false;
        }
    }

    public static function deleteProduct($product_id) {
        global $db;
    
         $query = "DELETE FROM product
                   WHERE productID = '$product_id'";
         $result=mysqli_query($db, $query);
         if($result==true){
             return true;
         }
         else {
             return false;
         }
     }

     public static function getTop1MostSoldProduct()
     {
        global $db;
        
        $query="SELECT product.* FROM product, kosnicka
                WHERE product.productID = kosnicka.productID AND kosnicka.isporacano='yes'
                GROUP BY kosnicka.productID
                ORDER BY COUNT(kosnicka.productID) DESC
                LIMIT 1";
       
        $result=mysqli_query($db,$query);

        $proizvodi = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $proizvod = new product($row['productID'],
                                 $row['name'],
                                 $row['price'],
                                 $row['picutre'],
                                 $row['active'],
                                 $row['featured'],
                                 $row['categoryID']);
        $proizvodi[]=$proizvod;
       }
       return $proizvodi;

        }
        else
        {
            $proizvodi="";
            return $proizvodi;
        }
       

     }
}