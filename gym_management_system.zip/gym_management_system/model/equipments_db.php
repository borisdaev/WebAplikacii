<?php
class equipments_db{
    public static function getEquipments(){
        global $db;
        
        $query="SELECT * FROM equipments
                ORDER BY id";
       
        $result=mysqli_query($db,$query);

        $equipments = array();
      
        $count = mysqli_num_rows($result);
        if($count > 0)
        {
        while($row = mysqli_fetch_assoc($result)) {
        $equipment = new equipments($row['id'],
                                 $row['name'],
                                 $row['picture'],
                                 $row['description']);
        $equipments[]=$equipment;
       }
       return $equipments;

        }
        else
        {
            $equipments="";
            return $equipments;
        }
       
        
    }
    }
?>