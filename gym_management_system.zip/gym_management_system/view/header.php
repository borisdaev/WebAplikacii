<!DOCTYPE html>
<html lang="zxx">
  <head>
    <meta charset="UTF-8" />
    <title>CollectiveMK - place for your fitness goals</title>
    <link rel="stylesheet" type="text/css"  href="<?php echo 'http://localhost/gym_management_system/'?>styles/stilovi.css">
  </head>
  <body>
    <!-- HEADER -->
    <header class="header" id="home">
      <div class="container">
        <nav class="header-navigation" aria-label="navigation">
          <div class="logo"><span class="purple">Collective</span>MK</div>
          <ul>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>">Home</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>ManageOurGymProducts">ManageOurGymProducts</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>Equipments">Equipments</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>Contact">Contact</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login">UserRegistration&Login</a></li>
          </ul>
        </nav>
      </div>
    </header>