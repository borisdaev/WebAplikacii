<?php
require('../model/database.php');
require('../model/korisnik.php');
require('../model/korisnik_db.php');
require('../model/equipments.php');
require('../model/equipments_db.php');

$equipments_id = filter_input(INPUT_GET, 'equipmentID', 
FILTER_VALIDATE_INT);

$action = filter_input(INPUT_GET, 'action');
if ($action == NULL) {
        $action = 'list_equipments';
}


if ($action == 'list_equipments') {
   
    $equipments = equipments_db::getEquipments();
    
    include('view/equipments.php');
}

?>