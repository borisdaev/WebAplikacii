<?php if(!isset($_SESSION['korisnik'])) {include('../view/header.php'); } else {include('../UserRegistration&Login/view/header.php'); }?>

<br><br><br>

<section style="background-color: rgb(105, 136, 126);padding: 4% 0;">
    <div style='width: 80%;margin: 0 auto;padding: 1%;'>
    
        <?php 
       
        if($equipments!=""){
               foreach ($equipments as $equipment) :
                    ?>

                    <a href="<?php echo 'http://localhost/gym_management_system/';?>Equipments/index.php?equipmentID=<?php echo $equipment->getID();?>"style='font-variant:small-caps;'>
                        <div style="padding: 20px 40px 40px;max-width: 800px;">
                            
                            <?php
                                 $slika=$equipment->getSlika();
                                if($slika == "") {
                                    echo "<div class='error'>Не е достапна слика.</div>";
                                } else {
                            ?>
                            <img style="width: 250px;margin: 30px 30px 30px 0;float: left;" src="<?php echo 'http://localhost/gym_management_system/'; ?>images/equipments/<?php echo $slika; ?>">
                            <?php
                        }
                    ?>
                    
                    <h3 class="center" style="display: inline;color:black;"><?php echo $equipment->getIme(); ?></h3>
                    <br>
                    <p class="center" style="display: inline;"><?php echo $equipment->getDescription(); ?></p>
                    
                </div>
            </a>
            <?php endforeach; ?>       
            <?php
            
        } else {
                echo "<div class='error'>Нема достапни категории.</div>";
        }
        ?>
        <div class="clearfix" style="clear: both;float: none;"></div>
        </div>
    </section>

<br>

<?php include('../view/footer.php') ?>