<?php include('../admin_view/header.php'); ?>

<br><br><br><br>

<div class="main-content">
    <div class="wrapper">

        

        <h2 style="text-align:center;color:rgb(54, 39, 48);border-bottom: 4px solid purple;font-style: italic;">What's new in the gym? Add it here and make it available to all customers.</h2>
        
        <br><br>

        <?php 
            if(isset($_SESSION['add'])) {
                echo $_SESSION['add'];
                unset($_SESSION['add']);
            }

            if(isset($_SESSION['upload'])) {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
        ?>

        <br><br>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="table_category">
                <tr>
                    <td>Name: </td>
                    <td>
                        <input type="text" name="name" placeholder="Enter new category.">
                    </td>
                </tr>
                <tr>
                    <td>Attach picture</td>
                    <td>
                        <input type="file" name="slika">
                    </td>
                </tr>
                <tr>
                    <td>Show it in other categories ?</td>
                    <td>
                        <input type="radio" name = "active" value="yes">Yes
                        <input type="radio" name = "active" value="no">No
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Category" class="btn-secondary" style="margin-left:400px">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>

<br><br><br><br>

<?php include('../admin_view/footer.php'); ?>