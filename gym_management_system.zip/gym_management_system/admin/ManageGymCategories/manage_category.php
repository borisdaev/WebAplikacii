<?php include('../admin_view/header.php'); ?>



<div class="main-content">
    <div class="wrapper">
        <h1>Category management</h1>

        <br /><br />

        <?php
            if(isset($_SESSION['add'])) {
                echo $_SESSION['add'];
                unset($_SESSION['add']);
            }
            if(isset($_SESSION['remove'])) {
                echo $_SESSION['remove'];
                unset($_SESSION['remove']);
            }
            if(isset($_SESSION['delete'])) {
                echo $_SESSION['delete'];
                unset($_SESSION['delete']);
            }
        ?>
        
        <br>
                
                <a href="<?php echo 'http://localhost/gym_management_system/';?>admin/ManageGymCategories?action=add" class="btn-primary">AddCategory</a>

                <br /><br /><br />

                <table class="tbl-full">
                    <tr>
                        <th style="color:red;">No.</th>
                        <th>Category</th>
                        <th>Picture</th>
                        <th>Active?</th>
                        <th>Аction</th>
                    </tr>

                    <?php
                        
                        $sn = 1;
                        
                        if($categories > 0) {
                            foreach($categories as $category) :
            

                                ?>
                                    <tr>
                                        <td style="color:red;text-decoration: underline;"><?php echo $sn++; ?></td>
                                        <td><?php echo $category->getIme(); ?></td>
                                        <td>
                                            <?php
                                            $slika=$category->getSlika();
                                               if($slika!="") {
                                                    ?>
                                                    <img src="<?php echo 'http://localhost/gym_management_system/';?>images/category/<?php echo $slika; ?>" width="100px">
                                                    <?php
                                               } else {
                                                    echo "<div class='error'>No picture</div>";
                                               }   
                                            ?>
                                        </td>
                                        <td><?php echo $category->getActive(); ?></td>
                                        <td>
                                            <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/ManageGymCategories?id=<?php echo $category->getID(); ?>&slika=<?php echo $slika;?>&action=delete" class="btn-danger">DeleteCategory</a>

                                        </td>
                                    </tr>
                                <?php endforeach;
                            
                        } else {
                            ?>

                            <tr>
                                <td colspan="5"><div class="error">No Added Categories</div></td>
                            </tr>

                            <?php 
                        }
                    ?>

                    
                </table>
    </div>
</div>

<?php include('../admin_view/footer.php'); ?>