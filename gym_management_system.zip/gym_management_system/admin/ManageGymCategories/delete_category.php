<?php
    include('../model/database.php');

    if(isset($_GET['id']) AND isset($_GET['slika'])) {
        $id = $_GET['id'];
        $slika = $_GET['slika'];

        if($slika != "") {
            $path = "../images/category/".$slika;
            $remove = unlink($path);
            if($remove == false) {
                $_SESSION['remove'] = "<div class='error'>Picture isn't deleted successfully..</div>";
                header('location:'.'http://localhost/gym_management_system/'.'admin/ManageGymCategories/manage_category.php');
                die();
            }
        }
        
        $sql = "DELETE FROM category WHERE id=$id";
        $res = mysqli_query($db, $sql);

        if($res == true) {
            $_SESSION['delete'] = "<div class='success'>Category deleted successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/manage_category.php');
        } else {
            $_SESSION['delete'] = "<div class='error'>Category is not deleted successfully</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/manage_category.php');
        }
    } else {
        header('location:'.'http://localhost/gym_management_system/'.'admin/manage_category.php');
    }
?>