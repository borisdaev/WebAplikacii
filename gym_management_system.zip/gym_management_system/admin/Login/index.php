<<?php

require('../../model/database.php');
require('../../model/admin.php');
require('../../model/admin_db.php');
require('../../util/secureconnection.php');

include('login.php');

if(isset($_POST['submit'])) {
    $korisnickoIme = $_POST['username'];
    $password = $_POST['password'];

    $admin=AdminDB::getAdmin($korisnickoIme,$password);

    if($admin!="") {
        $_SESSION['login'] = "<div class='success text-center'>Login Successfull.</div>";
        $_SESSION['user'] = $korisnickoIme; 

        header('location:'.'http://localhost/gym_management_system/'.'admin');
    } else {
        $_SESSION['login'] = "<div class='error text-center'>Incorrect password or username.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'admin/Login');
    }

    if(isset($_POST['remember_me'])) {
        $admin=['username_1' => $korisnickoIme, 'pass_1' => $password];

        $admin=serialize($admin);

        setcookie('admin', $admin, time() + (86400 * 30));
    }
}

 
?>