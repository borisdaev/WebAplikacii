<?php include('../admin_view/header.php'); ?>

<html>
    <head>
        <title>Admin-Login</title>
        <link rel="stylesheet" href="../../styles/stilovi.css">
    </head>

    <body>
    <br><br>
        <div class="wrapper" style="position:fixed;top: 25%;left: 37%;border: 1px solid blueviolet;">
            <h1 >Admin-Login</h1>

            <?php

                if(isset($_SESSION['login'])) {
                    echo $_SESSION['login'];
                    unset($_SESSION['login']);
                }
                if(isset($_SESSION['no-login-message'])) {
                    echo $_SESSION['no-login-message'];
                    unset($_SESSION['no-login-message']);
                }
            ?>
            <br><br>

            
            <form action="index.php" method="POST" >
                <div class="txt_field">
                    <input type="text" name="username" id="korisnickoIme" placeholder="Enter username.">
                    <span></span>
                <label>Username:<label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" id="pass" placeholder="Enter password.">
                    <span></span>
                    <label>Password:</label>
                </div>
                <input type="checkbox" name="remember_me"><label>Remember me?</label>
                <input type="submit" name="submit" value="LoginNow" >
            </form>
             
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </body>
</html>
<?php
if(isset($_COOKIE['admin'])) {
    $admin = unserialize($_COOKIE['admin']);            
    $username_1 = $admin['username_1'];
    $pass_1 = $admin['pass_1'];
    echo "<script>
        document.getElementById('korisnickoIme').value = '$username_1';
        document.getElementById('pass').value = '$pass_1';
    </script>";
}
?>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


<?php include('../../view/footer.php'); ?>