<?php include('../admin_view/header.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Product Management</h1>

        <br /><br />

                
                <a href="<?php echo 'http://localhost/gym_management_system/';?>admin/ManageOurGymProducts?action=add" class="btn-primary">Add Product</a>

                <br /><br />

                <?php 
                    if(isset($_SESSION['add'])) {
                        echo $_SESSION['add'];
                        unset($_SESSION['add']);
                    }
                    if(isset($_SESSION['delete'])) {
                        echo $_SESSION['delete'];
                        unset($_SESSION['delete']);
                    }
                    if(isset($_SESSION['upload'])) {
                        echo $_SESSION['upload'];
                        unset($_SESSION['upload']);
                    }
                    if(isset($_SESSION['unauthorized'])) {
                        echo $_SESSION['unauthorized'];
                        unset($_SESSION['unauthorized']);
                    }
                ?>

                <br><br>

                <table class="tbl-full">
                    <tr>
                        <th>No.</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Picture</th>
                        <th>Active?</th>
                        <th>Аctions</th>
                    </tr>
                    
                    <?php 
                       
                       if($products>0){
                        $sn = 1;
                        foreach($products as $product) :
                
                                ?>

                                <tr>
                                    <td><?php echo $sn++;?> </td>
                                    <td><?php echo $product->getIme(); ?></td>
                                    <td><?php echo $product->getCena(); ?></td>
                                    <td>
                                        <?php 
                                        $slika= $product->getSlika();
                                            if($slika == "") {
                                                echo "<div class='error'>No picture.</div>";
                                            } else {
                                                ?>
                                                <img src="<?php echo 'http://localhost/gym_management_system/'; ?>images/product/<?php echo $slika; ?>" width="100px">
                                                <?php
                                            }
                                        ?>
                                    </td>
                                    <td><?php echo  $product->getActive(); ?></td>
                                    <td>
                                        <a href="<?php echo 'http://localhost/gym_management_system/' ?>admin/ManageOurGymProducts?id=<?php echo  $product->getID(); ?>&slika=<?php echo $slika; ?>&action=delete" class="btn-danger">Delete product.</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php
                            
                        } else {
                            echo "<tr><td colspan='7' class='error'>Products not available.</td></tr>";
                        }
                    ?>

                    

                    
                </table>
    </div>
</div>

<?php include('../admin_view/footer.php'); ?>