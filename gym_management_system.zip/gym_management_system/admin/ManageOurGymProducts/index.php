<?php
ob_start();
require('../../model/database.php');
require('../../model/product.php');
require('../../model/product_db.php');
require('../../model/category.php');
require('../../model/category_db.php');

include('../admin_view/login_proverka.php');

$proizvod_id = filter_input(INPUT_GET, 'id', 
FILTER_VALIDATE_INT);
$action = filter_input(INPUT_GET, 'action');
$slika = filter_input(INPUT_GET, 'slika');


 if($proizvod_id != NULL && $action == 'delete')
 {

        if($slika != "") 
        {
            $path = "../../images/product/".$slika;
            $remove = unlink($path);
            if($remove == false) {
                $_SESSION['upload'] = "<div class='error'>The image is not deleted successfully.</div>"; 
                header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts');
                die();
            }
        }


    $check=product_db::deleteProduct($proizvod_id);

    if($check == true) {
        
        $_SESSION['delete'] = "<div class='success'>The product is deleted.</div>";
        
        header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts');
    } else {
        
        $_SESSION['delete'] = "<div success='error'>The product is not deleted successfully.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts');
    }
         
 }
 else if($action == 'add')
 {

    $kategorii=category_db::getCategories();
    

    include('add_product.php');

    if(isset($_POST['submit'])) {
        $ime = $_POST['name'];
        $cena = $_POST['price'];
        $kategorija = $_POST['category'];

        if(isset($_POST['active'])) {
            $active = $_POST['active'];
        } else {
            $active = "no";
        }

        

        if(isset($_FILES['slika']['name'])) {
            
            $slika = $_FILES['slika']['name'];
            
            if($slika!="") {
                $pom=explode('.', $slika);
                $ext = end($pom);
                $slika = "product_10".".".$ext;
                $src = $_FILES['slika']['tmp_name'];
                $dst = "../../images/product/".$slika;
                $upload = move_uploaded_file($src, $dst);
                if($upload == false) {
                    $_SESSION['upload'] = "<div class='error'>The image is not attached successfully.</div>";
                    header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts?action=add');
                    die();
                }
            } 
        } else {
            $slika = "";
        }

        $product= New product('', $ime,$cena,$slika,$active,$featured,$kategorija);
        $res2=product_db::addProduct($product);


        if($res2 == true) {
            
            $_SESSION['add'] = "<div class='success'>Product added successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts');
          
        } else {

            $_SESSION['add'] = "<div class='error'>The product is not added successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'admin/ManageOurGymProducts');
        

        }
    }


 }
 else
 {
     $products=product_db::getProducts();
     include('manage_products.php');
     ob_end_flush();
 }
?>