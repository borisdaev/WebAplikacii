<?php include('../admin_view/header.php');?>

<div class="main-content">
    <div class="wrapper">
        
        <br><br>

        <?php
            if(isset($_SESSION['upload'])) {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
        ?>

        <br><br>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="table_category">
                <tr>
                    <td>Product Name:</td>
                    <td>
                        <input type="text" name="name" placeholder="Enter a name of product.">
                    </td>
                </tr>
                <tr>
                    <td>Price:</td>
                    <td>
                        <input type="number" name="price">
                    </td>
                </tr>
                <tr>
                    <td>Attach picture:</td>
                    <td>
                        <input type="file" name="slika">
                    </td>
                </tr>
                <tr>
                    <td>Category:</td>
                    <td>
                        <select name="category">
                            <?php if($kategorii!=""){
                               foreach($kategorii as $kategorija) :
                                        ?>
                                        <option value="<?php echo $kategorija->getID(); ?>"><?php echo $kategorija->getIme(); ?></option>
                                        
                                        <?php endforeach ;?>   
                                        <?php } else { ?>
                                    <option value="0">No available categories.</option>
                                    <?php } ?></select>
                    </td>
                </tr>
                    <td>Show at product list? </td>
                    <td>
                        <input type="radio" value="yes" name="active">Yes
                        <input type="radio" value="no" name="active">No
                    </td>
                </tr>
                

                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Product" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>


    </div>
</div>

<br><br><br><br><br><br>

<?php include('../admin_view/footer.php');?>