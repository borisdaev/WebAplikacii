<?php
require('../model/database.php');
require('../model/category_db.php');
require('../model/category.php');
require('../model/product.php');
require('../model/product_db.php');
require('../model/korisnik.php');
require('../model/korisnik_db.php');



include('admin_view/login_proverka.php');



$kategorii=category_db::getCategories();
$products=product_db::getProducts();
$korisnici=korisnik_db::getKorisnici();

include('admin_home.php');
 
    
 
?>