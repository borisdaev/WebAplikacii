<?php include('admin_view/header.php'); ?>

<br>

<div class="main-content">
    <div class="wrapper">
        <h1 style="color:blueviolet; margin-left:500px; font-variant:small-caps;border-bottom: 5px solid black;">CollectiveMK dashboard</h1>
        <br><br>
        <?php
            if(isset($_SESSION['login'])) {
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
        ?>
        <br><br>
        <div class="col-3 text-center" style="color:black; margin-left:370px; font-variant:small-caps;font-style:italic;">
           
            <h1><?php echo count($kategorii); ?></h1>
            <br />
            Categories
        </div>

        <div class="col-3 text-center" style="color:black;font-variant:small-caps;font-style:italic;">
            
            <h1><?php echo count($products); ?></h1>
            <br />
            Products
        </div>

        <div class="col-3 text-center" style="color:black;font-variant:small-caps;font-style:italic;">
            
            <h1><?php echo count($korisnici); ?></h1>
            <br />
            Customers
        </div>


        <div class="clearfix"></div>
    </div>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>



<?php include('admin_view/footer.php'); ?>






