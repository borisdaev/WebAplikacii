<!DOCTYPE html>
<html lang="zxx">
  <head>
    <meta charset="UTF-8" />
    <title>CollectiveMK - place for your fitness goals</title>
    <link rel="stylesheet" type="text/css"  href="<?php echo 'http://localhost/gym_management_system/'; ?>styles/za_admin.css">
  </head>
  <body>
    <header class="header" id="home">
      <div class="container">
        <nav class="header-navigation" aria-label="navigation">
          <div class="logo"><span class="purple">Collective</span>MK</div>
          <ul>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/">Home</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/ManageOurGymProducts">ManageOurGymProducts</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/ManageGymCategories">ManageGymCategories</a></li>
          <li> <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/LogOut">LogOut</a></li>
          </ul>
        </nav>
      </div>
    </header>