<?php if(!isset($_SESSION['korisnik'])) {include('view/header.php'); } else {include('UserRegistration&Login/view/header.php'); }?>

<?php
            if(isset($_SESSION['login'])) {
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
?>

<br><br><br>


<section style="background-image: url(images/background.jpg); position: absolute; background-size: cover;;height: 80%;width: 100%;">
<p style="font-family: Times New Roman;position: absolute;top: 50px;left: 666px; font-size: 3.5em; font-variant:small-caps; color:aqua;"><b>Going to gym is great for your body , but it's also great for your mind</b></p>


<br><br>
<br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
        
<?php include('view/footer.php') ?>