<?php
require_once('model/database.php');

include('index_pom.php');

?>