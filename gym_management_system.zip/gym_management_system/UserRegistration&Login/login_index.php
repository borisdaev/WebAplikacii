<?php
    
    if(!isset($_SESSION['korisnik'])) { 
        $_SESSION['no-login-message'] = "<div class='error text-center'>Please login.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Login');
    }



?>