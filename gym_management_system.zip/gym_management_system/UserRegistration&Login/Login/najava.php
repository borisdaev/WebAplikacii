<?php include('../../view/header.php') ?>


<?php
if(isset($_SESSION['login'])) {
    echo $_SESSION['login'];
    unset($_SESSION['login']);
}
if(isset($_SESSION['no-login-message'])) {
    echo $_SESSION['no-login-message'];
    unset($_SESSION['no-login-message']);
}
?>

<br>
<br><br><br><br>

<div class="wrapper">
            <h1>Login</h1>


            <form action="" method="post">
                <div class="txt_field">
                    <input type="text" name="email" id="email" required>
                    <span></span>
                    <label>Email</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" id="pass" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <input type="checkbox" name="remember_me"><label>Remember me?</label>
                <input type="submit" name="submit" value="Login">
                <div class="signup_link">
                    New Member? <a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login/Register">Регистрирај се</a>
                    <br>
                    <a href="<?php echo 'http://localhost/gym_management_system/'; ?>admin/Login/">Log in as an admin</a>
                </div>
            </form>
        </div>


        <?php
        if(isset($_COOKIE['user'])) {
            $user = unserialize($_COOKIE['user']);
            $email = $user['email'];
            $pass = $user['pass'];
            echo "<script>
                document.getElementById('email').value = '$email';
                document.getElementById('pass').value = '$pass';
            </script>";
        }
        ?>

        <br><br><br><br><br><br>

<?php include('../../view/footer.php'); ?>