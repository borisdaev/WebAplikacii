<?php

require('../../model/database.php');
require('../../model/korisnik.php');
require('../../model/korisnik_db.php');
require('../../util/secureconnection.php');

include('najava.php');

if(isset($_POST['submit'])) {
    $korisnickoIme = $_POST['email'];
    $password = $_POST['password'];


    $korisnik=korisnik_db::getKorisnik($korisnickoIme,$password);


    if($korisnik!="") {
        $_SESSION['login'] = "<div class='success'>Login Successfull.</div>";
        $_SESSION['korisnik'] = $korisnickoIme; 

        header('location:'.'http://localhost/gym_management_system/');
    } else {
        $_SESSION['login'] = "<div class='error text-center'>Incorrect password or username , try again.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Login');
    }

    if(isset($_POST['remember_me'])) {
        $user=['email' => $korisnickoIme, 'pass' => $password];

        $user=serialize($user);

        setcookie('user', $user, time() + (86400 * 30));
    }
}

 
?>