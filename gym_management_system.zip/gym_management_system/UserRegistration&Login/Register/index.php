<?php

require('../../model/database.php');
require('../../model/korisnik.php');
require('../../model/korisnik_db.php');

$action = filter_input(INPUT_GET, 'result');


if($action != "reload")
{
    include('view/registracija.php');

if(isset($_POST['submit'])) 
{
        $ime=$_POST['name'];
        $prezime=$_POST['surname'];
        $adresa=$_POST['city'];
        $telefon=$_POST['phoneNumber'];
        $email=$_POST['email'];
        $lozinka=$_POST['password'];

        $korisnik=new korisnik('',$adresa,$ime,$prezime,$email,$lozinka,$telefon,"5");
        $res=korisnik_db::addKorisnik($korisnik);
        if($res == TRUE) 
        {
            $_SESSION['succesful'] = "<div class='success'>The user is added.</div>";
            header("location:".'http://localhost/gym_management_system/'."UserRegistration&Login/Register/uspesnaRegistracija.php?name=$ime&surname=$prezime&email=$email");
        } 
        else 
        {
            $_SESSION['successful'] = "<div class='error'>The user is not added successfully.</div>";
            header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Register?result=reload');
        }

    }
}

else

{
    include('view/registracija.php');
} 




?>