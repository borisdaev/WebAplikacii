<?php
    require('../../model/database.php');
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    
    require '../../vendor/autoload.php';
    require '../../vendor/phpmailer/phpmailer/src/Exception.php';
    require '../../vendor/phpmailer/phpmailer/src/PHPMailer.php'; 
    require '../../vendor/phpmailer/phpmailer/src/SMTP.php'; 

    $mail = new PHPMailer;
    
    try {
        $mail->SMTPDebug = 1;
        $mail->isSMTP();
        $mail->Host = 'smtp-mail.outlook.com';
        $mail->SMTPAuth = true;
        $mail->Username   = 'collectivemkweb@outlook.com'; 
        $mail->Password   = 'TestTest123';
        $mail->SMTPSecure = 'STARTTLS';
        $mail->Port = 587;

        $korisnikID = $_GET['KorisnikID'];
        $sql = "SELECT * FROM user WHERE userID = $korisnikID";
        $res = mysqli_query($db, $sql);
        $count = mysqli_num_rows($res);
        if($count>0) {
            while($row=mysqli_fetch_assoc($res)) {
                $ime = $row['name'];
                $prezime = $row['surname'];
                $email = $row['email'];
            }
        }

        $mail->setFrom('collectivemkweb@outlook.com', 'CollectiveMK');
        $mail->addAddress($email);

        $body = '<p>Dear '. $ime . ' ' . ',<br><br>Your order was sucessfull.</p>';

        $mail->isHTML(true);
        $mail->Subject = 'Order was successfull.';

        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        $mail->send();
        $_SESSION['mailNaracka'] = "<div class='success'>Check your email for successfull order.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    }catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
?>