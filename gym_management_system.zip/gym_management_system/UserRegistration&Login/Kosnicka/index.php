<?php
require('../../model/database.php');
require('../../model/kosnicka_db.php');
require('../../model/kosnicka.php');
require('../../model/product_db.php');
require('../../model/product.php');
require('../../model/korisnik.php');
require('../../model/korisnik_db.php');


$kosnicka_id = filter_input(INPUT_GET, 'id', 
FILTER_VALIDATE_INT);
$korisnik_id = filter_input(INPUT_GET, 'id', 
FILTER_VALIDATE_INT);
$action = filter_input(INPUT_GET, 'action');


if($kosnicka_id != NULL && $action == 'delete'){

    $check=kosnicka_db::deleteKoshnichka($kosnicka_id);
    if($check == true) {
        $_SESSION['delete'] = "<div class='success'>The product is deleted from the cart.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    } else {
        $_SESSION['delete'] = "<div success='error'>The product is not deleted successfully from the cart.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    }
}
else if($action == 'naracka'){
    $check=kosnicka_db::naracaj($korisnik_id);
    if($check == true){
        $_SESSION['naracano'] = "<div class='success'>Your order was successfull.</div>";

        header("location:".'http://localhost/gym_management_system/'."UserRegistration&Login/Kosnicka/uspesnaNaracka.php?KorisnikID=$korisnik_id");
    }
    else {
        $_SESSION['naracano'] = "<div class='error'>Your order was not sucessfull , try again.</div>";

        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    }
}
else if($action == 'deleteAll'){
    $check=kosnicka_db::deleteKoshnichki($korisnik_id);
    if($check == true){
        $_SESSION['delete2'] = "<div class='success'>All products are deleted.</div>";

        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    }
    else {
        $_SESSION['delete2'] = "<div success='error'>The products are not deleted.</div>";

        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Kosnicka');
    }
}
else{
    $kosnicki = kosnicka_db::getKoshnichki();
    $proizvodi =product_db::getProducts();
    
    if(isset($_SESSION['korisnik']))
    {
        $ime=$_SESSION['korisnik'];
        $korisnik=korisnik_db::getKorisnik($ime,'');
    }

    include('view/kosnicka.php');
}

?>