<?php include('../view/header.php') ?>
<?php          
	if(isset($_SESSION['delete'])) {
        echo $_SESSION['delete'];
        unset($_SESSION['delete']);
    }
					
	if(isset($_SESSION['delete2'])) {
        echo $_SESSION['delete2'];
        unset($_SESSION['delete2']);
    }

	if(isset($_SESSION['mailNaracka'])) {
		echo $_SESSION['mailNaracka'];
		unset($_SESSION['mailNaracka']);
	}
?>

<br><br><br>

<div style="margin: 0;padding: 0;background: linear-gradient(to bottom right, #E3F0FF, #FAFCFF);
	height: auto;display: flex;justify-content: center;align-items: center;">
   <div style="width: 70%;height: 90%;background-color: #ffffff;border-radius: 20px;box-shadow: 0px 10px 20px #1687d933;">
   	   <div style="margin: auto;width: 90%;height: 15%;display: flex;justify-content: space-between;align-items: center;">
   	   	<h3 style="font-size: 20px;font-family: 'Open Sans';font-weight: 700;color: #2F3841;">Cart</h3>
   	   	<h5 style="font-size: 14px;font-family: 'Open Sans';font-weight: 600;color: #E44C4C;cursor: pointer;
	border-bottom: 1px solid #E44C4C;"><a href="<?php echo 'http://localhost/gym_management_system/'?>UserRegistration&Login/Kosnicka?id=<?php echo $korisnik->getuserID(); ?>&action=deleteAll" style="text-decoration:none; color:#E44C4C;">Delete everything from cart </a></h5>
   	   </div>
       
	   <?php
	   $count=0;
	   $suma=0;
	   if($kosnicki!=""){
	    foreach($kosnicki as $kosnicka) {
		if($kosnicka->getIsporacano()=="no"){
			if($kosnicka->getKorisnikID()==$korisnik->getuserID()){
			$count++;
			$id1=$kosnicka->getProizvodID();
			foreach($proizvodi as $proizvod){
				$id2=$proizvod->getID();
				    if($id1==$id2){
			?>
   	   <div style="margin: auto;width: 90%;height: 30%;display: flex;justify-content: space-between;align-items: center;">
   	   	  <div style="width: 15%;text-align: center;">
			<?php $slika=$proizvod->getSlika(); ?>
   	   	  	<img src="<?php echo 'http://localhost/gym_management_system/'; ?>images/product/<?php echo $slika; ?>" style=' height:120px; ' >
   	   	  </div>
   	   	  <div style="height: 100%;width: 40%;">
			
   	   	  	<h1 style="padding-top: 5px;line-height: 5px;font-size: 22px;font-family: 'Arial';
						font-weight: 800;color: blueviolet;"><?php echo $proizvod->getIme() ?></h1>
			
   	   	  </div>
   	   	  
   	   	  <div style="height: 100%;text-align: right;">
			<?php $cenaProizvod = $proizvod->getCena();?>
   	   	  	<div style="padding-top: 20px;font-size: 26px;font-family: 'Open Sans';font-weight: 800;color: #202020;"><?php echo $cenaProizvod ?></div>
			<?php $suma += $cenaProizvod; ?>
   	   	  	<div style="padding-top: 5px;font-size: 14px;font-family: 'Open Sans';
					font-weight: 600;color: #E44C4C;cursor: pointer;"><a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login/Kosnicka?id=<?php echo $kosnicka->getID(); ?>&action=delete"><u>Delete</u> </a></div>
		</div>
   	   </div>
	   <?php } } } } } }?>

   	   
   	 <hr> 
   	 <div style="float: right;margin-right: 5%;width: 28%;">
   	 <div style="width: 100%;display: flex;justify-content: space-between;">
   	 	<div>
   	 		<div style="font-size: 22px;font-family: 'Open Sans';font-weight: 700;color: #202020;">In total</div>
   	 		<div style="font-size: 16px;font-family: 'Open Sans';font-weight: 500;
		color: #909090;line-height: 10px;"><?php if($count==1) {
				echo $count . " product"; }
				else if($count==2){
					echo $count . " products";}
				else { echo $count . " products"; }
				 ?></div>
   	 	</div>
   	 	<div style="font-size: 36px;font-family: 'Open Sans';font-weight: 900;color: #202020;"><?php echo $suma; ?></div>
   	 </div>
   	 <button style="margin-top: 10px;width: 100%;height: 40px;border: none;background: linear-gradient(to bottom right, #B8D7FF, #8EB7EB);
			border-radius: 20px;cursor: pointer;font-size: 16px;font-family: 'Open Sans';font-weight: 600;color: #202020;">
			<a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login/Kosnicka?id=<?php echo $korisnik->getuserID(); ?>&action=naracka" id="naracaj">Order now</a></button></div>
   </div>
</div>

<?php include('../view/footer.php') ?>