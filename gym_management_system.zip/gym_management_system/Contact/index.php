<?php
require('../model/database.php');

include('view/contact.php');

?>