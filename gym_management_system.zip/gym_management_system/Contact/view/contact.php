<?php if(!isset($_SESSION['korisnik'])) {include('../view/header.php'); } else {require('../util/secureconnection.php'); include('../UserRegistration&Login/view/header.php'); }?>

             <br>
             <br>
             <br>

             <div style="padding: 20px;">
             <div style="float:left; margin-left:80px; ">
             <iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d2978.044811884625!2d21.760040173225104!3d41.719551859751896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x135429dc893d6c77%3A0x1f1633286b8e338c!2zQ29sbGVjdGl2ZW1rLCBHb3NvIE9yZ2FuZHppZXYgMzUsINCS0LXQu9C10YEgMTQwMA!3m2!1d41.719549099999995!2d21.7613621!4m5!1s0x135429dc893d6c77%3A0x1f1633286b8e338c!2zQ29sbGVjdGl2ZW1rLCBHb3NvIE9yZ2FuZHppZXYsINCS0LXQu9C10YE!3m2!1d41.719549099999995!2d21.7613621!5e0!3m2!1smk!2smk!4v1674061466388!5m2!1smk!2smk" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>             </div>
             <div class="under">
             <div class="work_time">
                 <p class="crno">
                     <b style="font-size:2em; color:black"  >Работно време</b> <br> <br> <br> 
                    Понеделник-Петок: 08:00-22:30 <br>
                    Сабота-Недела: 08:00-17:00 <br>
                    <br> <br> <br>
                    Ѓошо Органџиев 35 , Велес
                    <br> <br> <br> <br>
                    Тел: +389 77 334 122 <br>
                    Email: <a href="mailto:collectivemkweb@outlook.com">collectivemkweb@outlook.com</a>
                </p>
             </div>
                <br><br><br>
                <div class="sliki">
                <img src="<?php echo 'http://localhost/gym_management_system/';?>images/facebook.png" height="30px" width="30px">
                <img src="<?php echo 'http://localhost/gym_management_system/';?>images/gmail.png" height="30x" width="30px">
             </div>
            </div>
            </div>
            <br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br>
            


<?php include('../view/footer.php');?>