<?php if(!isset($_SESSION['korisnik'])) {include('../view/header.php'); } else {include('../UserRegistration&Login/view/header.php'); }?>

<br><br><br>

<section style="background-color: rgb(105, 136, 126);padding: 4% 0;">
    <div style='width: 80%;margin: 0 auto;padding: 1%;'>
    
        <?php 
       
        if($kategorii!=""){
               foreach ($kategorii as $kategorija) :
                    ?>

                    <a href="<?php echo 'http://localhost/gym_management_system/';?>ManageOurGymProducts/index.php?categoryID=<?php echo $kategorija->getID();?>"style='font-variant:small-caps;'>
                        <div class="wrapper">
                            <?php
                                 $slika=$kategorija->getSlika();
                                if($slika == "") {
                                    echo "<div class='error'>The picture is not availbable..</div>";
                                } else {
                            ?>
                            <img src="<?php echo 'http://localhost/gym_management_system/'; ?>images/category/<?php echo $slika; ?>" style='height: 50%; width: 50%; margin-left:103px'>
                            <?php
                        }
                    ?>
                    <h3 class="center"><?php echo $kategorija->getIme(); ?></h3>
                </div>
            </a>
            <?php endforeach; ?>       
            <?php
            
        } else {
                echo "<div class='error'>No available categories.</div>";
        }
        ?>
        <div style="clear: both;float: none;"></div>
        </div>
    </section>

<br>

<?php include('../view/footer.php') ?>