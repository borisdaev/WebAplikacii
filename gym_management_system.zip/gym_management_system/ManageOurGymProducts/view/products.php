<?php if(!isset($_SESSION['korisnik'])) {include('../view/header.php'); } else {include('../UserRegistration&Login/view/header.php'); }?>

<br<br<br><br><br><br>

<section style="background-color:rgb(105, 136, 126);background-size: cover;background-repeat: no-repeat;
  background-position: center;padding: 7% 0;text-align:center;">
        <div style="width: 80%;margin: 0 auto;padding: 1%;">
            <h2>Category<a href="#"><?php echo $kategorija->getIme(); ?></a></h2>
        </div>
</section>

<section style="background-color: blueviolet;padding: 4% 0;">
    <div style="width: 80%;margin: 0 auto;padding: 1%;">
    <?php 
                if(isset($_SESSION['added-to-cart'])) 
                {
                    echo $_SESSION['added-to-cart'];
                    unset($_SESSION['added-to-cart']);
                }
            ?>
        <h2 style="text-align:center;">Gym Available Products</h2>
        <?php
        $categoryName=$kategorija->getIme(); 
        if($proizvodi!="")
        { foreach($proizvodi as $proizvod) :   ?>
                    
        <div style="width: 43%;margin: 1%;padding: 2%;float: left;background-color: white;border-radius: 15px;">
                        <div style="width: 20%;float: left;">
                            <?php 
                                
                                 $slika=$proizvod->getSlika();
                                if($slika=="") {
                                    echo "<div class='error'>No available picture at this moment.</div>";
                                } else {
                                    ?>
                                        <img src="<?php echo 'http://localhost/gym_management_system/';?>images/product/<?php echo $slika;?>"style="width: 100%;border-radius: 15px;">
                                    <?php
                                }
                            ?>
                        </div>
                        <div style="width: 70%;float: left;margin-left: 8%;">
                            <h4 style="color:black;"><?php echo $proizvod->getIme(); ?></h4>
                            <p style="font-size: 1.2rem;margin: 2% 0;color:black;"><?php echo $proizvod->getCena(); ?> денари</p>
                            <br>
                            <?php if(!isset($_SESSION['korisnik'])) { ?>
                            <a href="<?php echo 'http://localhost/gym_management_system/'; ?>UserRegistration&Login"style="background-color: blueviolet;padding: 1%;color: black;
                                            text-decoration: none;font-weight: bold;">Add to cart</a>
                            <?php } else { ?>
                             <a href="<?php echo 'http://localhost/gym_management_system/'; ?>ManageOurGymProducts?id=<?php echo $korisnik->getuserID(); ?>&action=add&pid=<?php echo $proizvod->getID(); ?>&action=add&cid=<?php echo $kategorija->getID(); ?>"style="background-color: blueviolet;padding: 1%;
                                                color: black;text-decoration: none;font-weight: bold;">Add to cart</a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php endforeach; ?> 
                    <?php
                }
             else {
                echo "<div class='error'>No available products of $categoryName .</div>";
            }
        ?>
        <div></div>
    </div>
</section>


<br><br><br><br><br><br><br><br><br>


<?php include('../view/footer.php') ?>