<?php
require('../model/database.php');
require('../model/category_db.php');
require('../model/category.php');
require('../model/product.php');
require('../model/product_db.php');
require('../model/korisnik.php');
require('../model/korisnik_db.php');
require('../model/kosnicka.php');
require('../model/kosnicka_db.php');



$category_id = filter_input(INPUT_GET, 'categoryID', 
FILTER_VALIDATE_INT);
$korisnik_id = filter_input(INPUT_GET, 'id');
$action = filter_input(INPUT_GET, 'action');
$proizvod_id = filter_input(INPUT_GET, 'pid');
$cid = filter_input(INPUT_GET, 'cid'); 

if ($category_id != NULL && $category_id != FALSE) {

   if(isset($_SESSION['korisnik']))
    {
        $ime=$_SESSION['korisnik'];
        $korisnik=korisnik_db::getKorisnik($ime,'');
    }

    $proizvodi = product_db::getProductsbyCategory($category_id);
    $kategorija = category_db::getCategory($category_id);

    include('view/products.php');
}
else if($korisnik_id !=NULL && $action != NULL && $proizvod_id!=NULL)
{
    $koshnicka = New kosnicka ('',$korisnik_id, $proizvod_id,"no");
    $check=kosnicka_db::addKoshnichka($koshnicka);
    if($check==true)
    {
        $_SESSION['added-to-cart'] = "<div class='success'>The product is added to cart.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'ManageOurGymProducts?categoryID='.$cid);

    } 
    else
    {
        $_SESSION['added-to-cart'] = "<div class='error'>The product is not added to cart.</div>";
        header('location:'.'http://localhost/gym_management_system/'.'ManageOurGymProducts?categoryID='.$cid);

    }
   

}
else
{

    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'list_categories';
    }


if ($action == 'list_categories') {
   
    $kategorii = category_db::getCategories();


    
    include('view/categories.php');
  }

}

    
    
 
?>