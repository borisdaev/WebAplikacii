<?php if(!isset($_SESSION['korisnik'])) {include('view/header.php'); } else {include('UserRegistration&Login/view/header.php'); }?>

<?php
            if(isset($_SESSION['login'])) {
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
?>
        <h1>ПРОБА
<?php include('view/footer.php') ?>