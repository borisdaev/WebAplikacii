<?php
    
    if(!isset($_SESSION['korisnik'])) { 
        $_SESSION['no-login-message'] = "<div class='error text-center'>Ве молиме да се Најавите</div>";
        header('location:'.'http://localhost/gym_management_system/'.'UserRegistration&Login/Login');
    }



?>