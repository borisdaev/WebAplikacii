<?php
require('../model/database.php');
require('../util/secureconnection.php'); 


include('login_index.php');


 
?>

